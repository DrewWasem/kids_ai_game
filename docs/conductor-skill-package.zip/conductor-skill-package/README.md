# Conductor Skill Package

A complete orchestration system for managing complex software development tasks through a disciplined Research → Plan → Implement workflow.

## Overview

The Conductor is an orchestration skill that ensures significant work follows a structured process, preventing wasted effort and ensuring alignment before implementation.

## Package Contents

```
conductor-skill-package/
├── commands/               # User-invocable commands
│   ├── conductor.md       # Main orchestration entry point
│   ├── brainstorm.md      # Phase 0: Requirements alignment
│   ├── research.md        # Phase 1: Codebase investigation
│   ├── create-plan.md     # Phase 2: Implementation design
│   ├── implement-plan.md  # Phase 3: Execution
│   ├── validate-plan.md   # Phase 4: Verification
│   ├── remember.md        # Phase 5: Knowledge capture
│   └── recall.md          # Context retrieval
├── skills/                # Full skill definitions
│   ├── conductor/         # Main orchestration protocol
│   ├── research/          # Research methodology
│   ├── planning/          # Plan creation guidelines
│   ├── remember/          # Memory persistence
│   ├── recall/            # Memory retrieval
│   └── memory/            # Memory system management
├── agents/                # Specialized sub-agents
│   ├── memory-locator.md      # Find relevant memories
│   ├── memory-writer.md       # Write memory entries
│   ├── codebase-researcher.md # Map file locations
│   ├── codebase-analyzer.md   # Trace code paths
│   ├── plan-architect.md      # Design implementation plans
│   ├── implementer.md         # Execute plan tasks
│   └── reviewer.md            # Verify implementation
├── hooks/                 # Automation scripts
│   ├── session_start_recall.sh    # Load context on startup
│   ├── pre_compact_remember.sh    # Save before compaction
│   ├── post_compact_recall.sh     # Restore after compaction
│   └── stop_remember_nudge.sh     # Periodic memory nudge
└── README.md             # This file
```

## The Orchestrated Workflow

```
┌───────────┐     ┌─────────┐     ┌──────┐     ┌───────────┐     ┌──────────┐     ┌──────────┐
│ BRAINSTORM│────▶│ RESEARCH │────▶│ PLAN │────▶│  APPROVE  │────▶│IMPLEMENT │────▶│ VALIDATE │
│/brainstorm│     │ /research│     │/create│     │  (human)  │     │/implement│     │/validate │
│ (optional)│     │          │     │ -plan │     │           │     │  -plan   │     │  -plan   │
└───────────┘     └─────────┘     └──────┘     └───────────┘     └──────────┘     └──────────┘
                       │               │                               │                │
                       ▼               ▼                               ▼                ▼
                    memory/         memory/                         memory/          memory/
                    research/       plans/                          sessions/        research/
```

## When to Use the Conductor

**Orchestrate (complex tasks) when ANY of these are true:**
- The task touches 3+ files
- You're unfamiliar with the relevant code area
- Multiple valid approaches exist
- The task involves architectural decisions
- You're about to write more than ~50 lines of new code
- The task requires understanding data flow across components

**Just do it (trivial tasks) when ALL of these are true:**
- Single file change
- The solution is obvious and unambiguous
- The user gave specific instructions
- No architectural impact

## Phase Descriptions

### Phase 0: Brainstorm (`/brainstorm` — optional)
- Use when requirements are ambiguous or multiple approaches exist
- Ask questions one at a time (Socratic, not a questionnaire)
- Propose 2-3 approaches with trade-offs
- Get alignment before committing to research scope
- Save architectural decisions to `.claude/memory/decisions/`

### Phase 1: Research (`/research {topic}`)
- Dispatch parallel agents to understand the codebase
- Check memory for prior knowledge
- Save structured findings to `.claude/memory/research/`
- Present findings to user
- **Human reviews research before planning begins**

### Phase 2: Plan (`/create-plan`)
- Use research findings as input
- Design phased approach with 2-5 minute tasks
- Every task has exact file paths and verification steps
- Save plan to `.claude/memory/plans/`
- **Human reviews and approves plan before implementation begins**

### Phase 3: Implement (`/implement-plan {filename}`)
- Execute plan one phase at a time
- Verify each task before moving on
- Stop on mismatches — never improvise
- **Human reviews each phase before the next begins**

### Phase 4: Validate (`/validate-plan {filename}`)
- Independent verification of all success criteria
- Two-pass review: spec compliance, then code quality
- Save validation report to memory

### Phase 5: Remember (`/remember`)
- Capture decisions, patterns, and bugs from the session
- Write session summary
- Persist learnings for future sessions

## Installation

1. **Copy to your project:**
   ```bash
   cp -r conductor-skill-package/.claude/commands/* your-project/.claude/commands/
   cp -r conductor-skill-package/.claude/skills/* your-project/.claude/skills/
   cp -r conductor-skill-package/.claude/agents/* your-project/.claude/agents/
   cp -r conductor-skill-package/.claude/hooks/* your-project/.claude/hooks/
   ```

2. **Make hooks executable:**
   ```bash
   chmod +x your-project/.claude/hooks/*.sh
   ```

3. **Create memory tree structure:**
   ```bash
   mkdir -p your-project/.claude/memory/{decisions,patterns,bugs,preferences,context,sessions,plans,research,files}
   ```

4. **Create root memory index:**
   ```bash
   cat > your-project/.claude/memory/_index.md << 'EOF'
   # Memory Tree

   Root index for the project memory system.

   ## Domains

   | Domain | Description | Updated |
   |---|---|---|
   | decisions/ | Architecture, tech choices, strategic decisions | - |
   | patterns/ | Reusable solutions, code patterns, techniques | - |
   | bugs/ | Bugs encountered, root causes, fixes | - |
   | preferences/ | User style, conventions, tool preferences | - |
   | context/ | Project architecture, domain knowledge, business logic | - |
   | sessions/ | Auto-generated session summaries | - |
   | plans/ | Implementation plans (living docs with checkboxes) | - |
   | files/ | Project file directory index (auto-updated each session) | - |
   | research/ | Codebase research documents | - |
   EOF
   ```

## Usage

### Quick Start

```bash
# For complex tasks
/conductor {describe your task}

# For specific phases
/brainstorm {topic}         # Align on requirements
/research {topic}           # Investigate codebase
/create-plan                # Design solution
/implement-plan {filename}  # Execute plan
/validate-plan {filename}   # Verify implementation
/remember                   # Capture learnings
```

### Example Session

```
User: "Add user authentication to the app"

Claude: **Conducting: Research** — investigating authentication patterns in codebase
[Dispatches codebase-researcher and codebase-analyzer agents]
[Presents research findings]

Claude: **Conducting: Planning** — designing implementation approach
[Creates phased plan with verification steps]
[Saves to .claude/memory/plans/add-user-auth-plan.md]

User: [Reviews and approves plan]

Claude: **Conducting: Implementation** — executing Phase 1
[Implements database schema changes]
[Verifies with tests]
[Updates plan checkboxes]

Claude: **Conducting: Validation** — verifying implementation
[Independent review of spec compliance and code quality]

Claude: **Conducting: Remember** — capturing learnings
[Saves session summary and architectural decisions]
```

## Agent Roster

| Agent | Role | When Used |
|-------|------|-----------|
| **memory-locator** | Find relevant memories | Research, Planning |
| **memory-writer** | Write entries to memory tree | Remember, Research |
| **codebase-researcher** | Find files and components | Research |
| **codebase-analyzer** | Trace code paths in depth | Research |
| **plan-architect** | Design implementation plans | Planning |
| **implementer** | Execute plan tasks precisely | Implementation |
| **reviewer** | Verify spec compliance + quality | Validation |

## Context Management

The Conductor workflow is designed for **context efficiency**:

1. **Research agents run in subagent context** — their file reads and searches don't pollute the parent window.
2. **Plans are saved to disk** — if context fills, compact and resume from the plan file.
3. **Implementation tracks progress with checkboxes** — you can always see what's done and what's next.
4. **Memory persists across sessions** — `/recall` recovers context from previous sessions.

### Intentional Compaction

If context is getting full mid-workflow:
1. Save current progress: update plan checkboxes, write session notes.
2. Let compaction happen — the post-compact hook will re-inject key context.
3. Resume from the plan file: read it, find the first unchecked task, continue.

## Anti-Rationalization

Watch for these thoughts — they are signals to STOP and follow the workflow, not skip it.

| Thought | Reality |
|---------|---------|
| "This is simple, I'll just..." | If it touches 3+ files, it's not simple. Orchestrate. |
| "I know how to do this" | In unfamiliar code, you're guessing. Research first. |
| "Let me just try something" | Trying without reading the code first = rework. |
| "I'll fix this other thing while I'm here" | That's scope creep. Finish the current task. |
| "The user wants it fast, not perfect" | Building the wrong thing is the slowest path. |
| "I'll test after I implement" | Tests written after rationalize the implementation. Test-first. |
| "Planning will slow us down" | A 5-minute plan saves a 30-minute redo. |
| "I already explored this area before" | Context decays. Check memory or re-read the code. |
| "This doesn't need a brainstorm" | If there are 2+ valid approaches, it does. Run `/brainstorm`. |
| "I can hold all this in my head" | Context windows compact. Save state to disk. |

## Memory System

The Conductor relies on a persistent memory tree at `.claude/memory/`:

```
.claude/memory/
├── _index.md          # Root index
├── decisions/         # Architecture, tech choices, strategic decisions
├── patterns/          # Reusable solutions, code patterns, techniques
├── bugs/              # Bugs encountered, root causes, fixes
├── preferences/       # User style, conventions, tool preferences
├── context/           # Project architecture, domain knowledge
├── sessions/          # Auto-generated session summaries
├── plans/             # Implementation plans (living docs with checkboxes)
├── research/          # Codebase research documents
└── files/             # Auto-maintained project file directory index
```

### Memory Entry Format

```markdown
# [Title]

**Created:** YYYY-MM-DD
**Last Updated:** YYYY-MM-DD
**Source:** session
**Confidence:** high | medium | low
**Tags:** comma-separated-tags

## Summary
[1-3 sentence summary]

## Details
[Full content]

## Related
[Links to related files or memories]
```

## Hooks

The package includes automation hooks for seamless memory management:

- **session_start_recall.sh** — Loads last session context on startup
- **pre_compact_remember.sh** — Saves state before context compaction
- **post_compact_recall.sh** — Restores context after compaction
- **stop_remember_nudge.sh** — Reminds to run `/remember` every ~30 messages

Configure hooks in your project's `.claude/settings.json`:

```json
{
  "hooks": {
    "session_start": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/session_start_recall.sh\"",
    "pre_compact": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/pre_compact_remember.sh\"",
    "post_compact": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/post_compact_recall.sh\"",
    "stop": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/stop_remember_nudge.sh\""
  }
}
```

## Best Practices

1. **Always assess before acting** — Check if the task needs orchestration
2. **Research before planning** — Never plan from assumptions
3. **Plan before implementing** — A 5-minute plan saves hours of rework
4. **Verify after each phase** — Catch mismatches early
5. **Remember after completion** — Capture learnings for future sessions
6. **Trust the process** — The workflow exists to prevent common failure modes

## Troubleshooting

**Q: The conductor says my task is trivial, but I think it's complex.**
A: Explicitly request orchestration: `/conductor {task}` — the conductor will always comply.

**Q: Context filled up mid-implementation. What now?**
A: Update plan checkboxes, let compaction happen, then read the plan file to resume.

**Q: Research agents returned too much information.**
A: That's intentional — they run in subagent context. The conductor summarizes findings for you.

**Q: How do I know which phase I'm in?**
A: The conductor announces phase transitions: "**Conducting: Research**", "**Conducting: Planning**", etc.

**Q: Can I skip phases?**
A: No. Each phase builds on the previous. Skipping phases leads to wrong assumptions and rework.

## License

This skill package is part of the COHERANY project and is provided as-is for use in software development workflows.

## Version

**Package Version:** 1.0.0
**Created:** 2026-02-10
**Source Project:** COHERANY

---

**For more information, see:**
- `.claude/skills/conductor/SKILL.md` — Complete skill protocol
- `.claude/commands/conductor.md` — Quick reference guide